var stringToHTML = function (str) {
    var dom = document.createElement('div');
    dom.innerHTML = str;
    return dom;
};
eel.expose(calendar);
function calendar(html_content){
    var calendar_element = document.getElementsByClassName('calendar-container')[0];
    while(calendar_element.lastChild){
        calendar_element.removeChild(calendar_element.lastChild);
    }
    calendar_element.appendChild(stringToHTML(html_content));
    calendar_element.style.visibility = "hidden";
    tr_element = document.getElementsByTagName('tr');

    var inc = 40;

    while(document.getElementsByTagName('table')[0].clientHeight < 500){
        for(var i=0; i<tr_element.length; i++){
            tr_element[i].style.height = inc + "px";
        };
        inc += 5;
    }

    var tr_element = document.getElementsByTagName('tr')[0];
    tr_element.remove()

    td_element = document.getElementsByTagName('td');
    for(var i=0; i<td_element.length; i++){
        var p_element = document.createElement("p");
        p_element.setAttribute('class', 'day_p')
        var div_element = document.createElement("div");
        div_element.setAttribute('class','day');
        p_element.textContent = td_element[i].textContent;
        td_element[i].textContent = "";
        div_element.insertBefore(p_element, div_element.firstChild);
        td_element[i].insertBefore(div_element, td_element[i].firstChild);
    };
};
eel.expose(active_button);
function active_button(row, colmun){
    day_element = document.getElementsByClassName('day_p')[row*7 + colmun];
    console.log(row*7 + colmun)
    day_element.classList.add("day_p", "mark");
};
eel.expose(insert_month);
function insert_month(month_text){
    var month_element = document.createElement("dev");
    month_element.setAttribute("class","month");

    let left_element = document.createElement("dev");
    left_element.setAttribute("class","left-button");
    
    let right_element = document.createElement("dev");
    right_element.setAttribute("class","right-button");
    let h3_element = document.createElement("h3");
    h3_element.textContent = month_text;
    let left_button_element = document.createElement("p");
    let right_button_element = document.createElement("p");
    left_button_element.setAttribute('onclick', 'eel.change_calendar(1)');
    right_button_element.setAttribute('onclick', 'eel.change_calendar(0)');

    left_element.insertBefore(left_button_element, left_element.firstChild);
    right_element.insertBefore(right_button_element, right_element.firstChild);

    month_element.insertBefore(right_element, month_element.firstChild);
    month_element.insertBefore(h3_element, month_element.firstChild);
    month_element.insertBefore(left_element, month_element.firstChild);

    var parentDiv = document.getElementsByClassName("calendar-container")[0];
    parentDiv.insertBefore(month_element, parentDiv.firstChild);

    document.getElementsByClassName('calendar-container')[0].style.visibility = "visible";
};